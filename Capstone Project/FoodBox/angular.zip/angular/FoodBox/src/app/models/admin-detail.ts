export class AdminDetail {
	adminId: string;
    username : string;
	name : string;
	password : string ;
	role : string;
}